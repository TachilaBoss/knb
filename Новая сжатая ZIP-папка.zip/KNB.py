import random
import psycopg2
from config import  host, user, password, db_name

connection = None

try:
    connection = psycopg2.connect(
        host=host,
        user=user,
        password=password,
        database=db_name,
    )

    connection.autocommit = True


    with connection.cursor() as cursor:
        cursor.execute(
            """
            CREATE TABLE game_results (
                id SERIAL PRIMARY KEY,
                result VARCHAR(20) NOT NULL,
                game_date TIMESTAMP NOT NULL
            );
            """
        )
        print(f"Server version: {cursor.fetchone()}")


except Exception as _ex:
    print("[INFO]")



finally:
    if connection:
        connection.close()
        print("INFO Close")


while True:
    user_action = input("Сделайте выбор — Камень, Ножницы, Бумага: ")
    user_action == ("Камень")
    possible_actions = ["Камень", "Бумага", "Ножницы"]
    computer_action = random.choice(possible_actions)
    print(f"\nВы выбрали {user_action}, компьютер выбрал {computer_action}.\n")
    if user_action == computer_action:
        print(f"Оба пользователя выбрали {user_action}. Ничья!!")
    elif user_action == "Камень":
        if computer_action == "Ножницы":
            print("Камень бьет Ножницы! Вы победили!")
        else:
            print("Бумага оборачивает Камень! Вы проиграли.")
    elif user_action == "Бумага":
        if computer_action == "Камень":
            print("Бумага оборачивает Камень! Вы победили!")
        else:
            print("Ножницы режут Бумагу! Вы проиграли.")
    elif user_action == "Ножницы":
        if computer_action == "Бумага":
            print("Ножницы режут Бумагу! Вы победили!")
        else:
            print("Камень бьет Ножницы! Вы проиграли.")
    play_again = input("Сыграем еще? (Да/Нет): ")
    if play_again != "Да":
        break